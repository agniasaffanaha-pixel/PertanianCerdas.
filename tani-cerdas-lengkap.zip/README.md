# TANI CERDAS — Asisten Digital Budidaya Pertanian
Hitung Tepat, Pantau Tanaman, Tingkatkan Hasil Panen.

## Cara menjalankan
Buka `index.html` (satu berkas lengkap: semua halaman, gaya, dan rumus). Tanpa instalasi.

## Isi index.html
Dashboard, Kalkulator Pupuk, Perkecambahan, Pemantauan Tanaman, Evaluasi Budidaya, Kalender Budidaya, Keluhan Petani, Manajemen Lahan, Laporan, Pengaturan.

## Folder sumber-modular/
Versi yang sama dipecah per berkas (css/, js/, js/pages/, tests/) untuk pengembangan. Uji rumus: `node sumber-modular/tests/calc.test.js`.

## Batasan
Data tersimpan di browser (localStorage); data contoh adalah simulasi. Belum ada login Google, database online, unggah foto, atau notifikasi. Dosis pupuk hanya contoh uji hitung.
