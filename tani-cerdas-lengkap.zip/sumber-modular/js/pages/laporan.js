/* ----- Laporan ----- */
R.lap=()=>{M.innerHTML=head('Laporan & Ekspor','Pilih laporan lalu cetak / simpan sebagai PDF.')+`<div class="np card">${sel('rp','Jenis laporan',['Kebutuhan pupuk','Perkecambahan','Pertumbuhan tanaman','Hasil panen','Biaya produksi','Rekapitulasi keluhan'],'onchange="rl()"')}<button class="btn" onclick="window.print()">🖨 Cetak / PDF</button></div><div class="card" id="rb"></div>`;rl()};
function rl(){const t=v('rp'),h=`<h3>Laporan ${t} — TANI CERDAS</h3><p>Dibuat: ${today()} · Lahan: ${S.lahan.map(l=>esc(l.nama)+' ('+fmt(l.luas)+' m²)').join(', ')}</p>`;let b='';
 if(t=='Kebutuhan pupuk')b=tbl(['Tanggal','Lahan','Luas m²','Hara','Dosis kg/ha','Kebutuhan hara kg','Pupuk','Produk g'],S.hitung.flatMap(x=>x.rows.map(r=>[x.tgl,esc(x.lahan),fmt(x.m2),r.lab,fmt(r.dose),fmt(r.need,4),r.f,fmt(r.g)])));
 if(t=='Perkecambahan')b=tbl(['Tanggal','Komoditas','Diuji','Kecambah','%'],S.kec.map(k=>[k.tgl,esc(k.kom),k.uji,k.kecambah,fmt(Calc.germ(k.uji,k.kecambah),1)]));
 if(t=='Pertumbuhan tanaman')b=tbl(['Tanggal','Lahan','Hidup','Awal','Tinggi cm'],S.tumbuh.map(x=>[x.tgl,esc(x.lahan),x.hidup,x.awal,x.tinggi]));
 if(t=='Hasil panen')b=tbl(['Tanggal','Lahan','Panen kg','Target kg','Pencapaian %','Produktivitas kg/ha','Mutu'],S.panen.map(p=>[p.tgl,esc(p.lahan),fmt(p.kg),fmt(p.target),fmt(p.target?p.kg/p.target*100:0,1),fmt(Calc.prod(p.kg,p.luas/10000)||0),p.mutu]));
 if(t=='Biaya produksi')b=tbl(['Tanggal','Kegiatan','Biaya (Rp)'],S.giat.map(g=>[g.tgl,g.jenis,fmt(g.biaya,0)]))+`<p><b>Total: Rp ${fmt(S.giat.reduce((a,g)=>a+g.biaya,0),0)}</b></p>`;
 if(t=='Rekapitulasi keluhan')b=tbl(['Tanggal','Kategori','Komoditas','Status'],S.keluhan.map(k=>[k.tgl,k.kat,esc(k.kom),k.status]));
 $('rb').innerHTML=h+b+'<small class="sub">Indikator pemantauan, bukan jaminan hasil panen.</small>'}
