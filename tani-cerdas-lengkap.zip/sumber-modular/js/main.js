go(location.hash.slice(1)in R?location.hash.slice(1):'dash');
try{if(window.claude)initCloud()}catch(e){}
